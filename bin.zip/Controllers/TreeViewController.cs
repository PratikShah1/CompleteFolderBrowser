﻿using System;
using System.Collections.Generic;
using System.IO;
using Bootstrap.Models;
using System.Web.Mvc;
using System.Linq;
using FolderBrowser.Models;

namespace Bootstrap.Controllers
{
    public class TreeViewController : Controller
    {
        [HttpPost]
        public JsonResult TreeData(string baseDir)
        {
            var patt = Server.MapPath(@"~\"+ baseDir);
            var browsingRoot = Path.Combine(patt, "");
            var nodes = new List<TreeNode>();
            nodes.AddRange(RecurseDirectory(browsingRoot));

            return Json(nodes, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult GetFiles(string directory)
        {
            var dirInfo = new DirectoryInfo(directory);
            var fileView = new List<FileViewModal>();
            var files = dirInfo.GetFiles();

            foreach (var file in files)
            {
                var fv = new FileViewModal();
                fv.FileName = file.Name;
                fv.FileType = file.Extension;
                fv.LastUpdated = file.LastAccessTime;
                fv.ActualSize = file.Length;
                fv.Path = file.FullName;
                string[] filePaths = file.FullName.Split(new[] { AppDomain.CurrentDomain.BaseDirectory }, StringSplitOptions.None);

                fv.ServerPath = filePaths[1]; 
                fileView.Add(fv);
            }

            return PartialView(fileView);
        }

        [HttpPost]
        public bool DeleteFiles(List<string> files)
        {
            try
            {
                foreach (var file in files)
                {
                    var filePath = AppDomain.CurrentDomain.BaseDirectory + file;
                    if (System.IO.File.Exists(filePath))
                    {
                        System.IO.File.Delete(filePath);
                    }
                }
                return true;
            }
            catch (Exception e)
            {
                //Debug.WriteLine(e.Message);
            }
            return false;
        }

        [HttpPost]
        public bool CreateFolder(string folderName, string path)
        {
            Directory.CreateDirectory(path + "/" + folderName);
            return true;
        }

        [HttpPost]
        public bool DeleteFolder(string folderPath)
        {
            Directory.Delete(folderPath, true);
            return true;
        }

        [HttpPost]
        public bool FolderRename(string oldPath, string newName)
        {
            string lastFolderName = Path.GetDirectoryName(oldPath);
            string oldPath1 = new DirectoryInfo(oldPath).Name;
            Directory.Move(oldPath, lastFolderName + "\\" + newName);
            return true;
        }

        [HttpGet]
        public string GetFolderName(string path)
        {
            string folderName = new DirectoryInfo(path).Name;
            return folderName;
        }

        private List<TreeNode> RecurseDirectory(string directory)
        {
            var ret = new List<TreeNode>();
            var dirInfo = new DirectoryInfo(directory);


            try
            {
                var directories = dirInfo.GetDirectories("*", SearchOption.TopDirectoryOnly);

                foreach (var dir in directories)
                {

                    if (dir.FullName.ToLower() == dirInfo.FullName)
                    {
                        continue;
                    }

                    var thisNode = TreeNode.FromDirInfo(dir);
                    thisNode.nodes.AddRange(RecurseDirectory(dir.FullName));
                    ret.Add(thisNode);

                    //var files = dirInfo.GetFiles();

                    //foreach (var file in files)
                    //{
                    //    var thisFileNode = TreeNode.FromFileInfo(file, id, 0);
                    //    id++;
                    //    //parentId++;
                    //    bool containsItem = ret.Any(item => item.text == thisFileNode.text);
                    //    if (!containsItem)
                    //    {
                    //        ret.Add(thisFileNode);
                    //    }
                    //}
                }
            }
            catch (UnauthorizedAccessException ux)
            {
                // NB Log.
            }

            return ret;
        }
    }
}