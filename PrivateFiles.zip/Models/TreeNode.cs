﻿using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace Bootstrap.Models
{
    public class TreeNode
    {
        public string text { get; set; }

        public string icon { get; set; }

        public string href { get; set; }

        public string path { get; set; }

        public List<TreeNode> nodes { get; set; } = new List<TreeNode>();

        public static TreeNode FromDirInfo(DirectoryInfo directoryInfo)
        {
            var node = new TreeNode
            {
                text = directoryInfo.Name,
                icon = "glyphicons glyphicon glyphicon-folder-close",
                href = "",
                path = directoryInfo.FullName
            };
            return node;
        }

        public static TreeNode FromFileInfo(FileInfo fileInfo)
        {
            var node = new TreeNode
            {
                text = fileInfo.Name,
                icon = "glyphicon glyphicon-file",
                href = "/Content/Images/filename.html",
                path = fileInfo.FullName
            };
            return node;
        }
    }
}
