﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FolderBrowser.Models
{
    public class FileViewModal
    {
        public string FileName
        {
            get;
            set;
        }
        public string FileType
        {
            get;
            set;
        }
        public DateTime LastUpdated
        {
            get;
            set;
        }
        public long ActualSize
        {
            get;
            set;
        }
        public string Path
        {
            get;
            set;
        }
        public string ServerPath
        {
            get;
            set;
        }
    }
}